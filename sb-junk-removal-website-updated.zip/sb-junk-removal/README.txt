SB JUNK REMOVAL - FREE WEBSITE

Files:
- index.html: complete responsive website

The quote form uses a mailto link, so it does not require a paid form service. When a customer submits the form, their device's email app opens with the quote request addressed to rguerrero1080p60@gmail.com.

FREE HOSTING OPTION: GitHub Pages
1. Create a free account at github.com.
2. Create a new public repository named sb-junk-removal (or any name).
3. Upload index.html.
4. Open Settings > Pages.
5. Choose Deploy from a branch, select main and / (root), then Save.
6. GitHub will give you a free website address such as https://YOURUSERNAME.github.io/sb-junk-removal/

NOTE: The photos currently use Unsplash image URLs, so an internet connection is needed to display them. You can replace them with your own job photos later for a more authentic site.
